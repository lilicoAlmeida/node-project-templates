const express = require('express');
const app = express();

app.use('/api', require('./routes'));

app.listen(process.env.PORT, () => console.log(`API running on port ${process.env.PORT}`));